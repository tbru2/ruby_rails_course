class TodoItem < ApplicationRecord
end
